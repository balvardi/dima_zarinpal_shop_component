<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Dima_zarinpal
 * @author     Dima Group <info@dima.ir>
 * @copyright  Copyright (C) 2021 Dima Software Group. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Categories\Categories;
/**
 * Content Component Category Tree
 *
 * @since  1.6
 */

class Dima_zarinpalProductsCategories extends Categories
{
	/**
	 * Class constructor
	 *
	 * @param   array  $options  Array of options
	 *
	 * @since   11.1
	 */
	public function __construct($options = array())
	{
		$options['table'] = '#__dima_zarinpal_products';
		$options['extension'] = 'com_dima_zarinpal.products';
		parent::__construct($options);
	}
}
