<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Dima_zarinpal
 * @author     Dima Group <info@dima.ir>
 * @copyright  Copyright (C) 2021 Dima Software Group. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;


?>

<div class="item_fields">

	<table class="table">
		

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_TITLE'); ?></th>
			<td><?php echo $this->item->title; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_DESCRIPTION'); ?></th>
			<td><?php echo nl2br($this->item->description); ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_DETAILS'); ?></th>
			<td><?php echo nl2br($this->item->details); ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_PHOTO'); ?></th>
			<td>
			<?php
			foreach ((array) $this->item->photo as $singleFile) : 
				if (!is_array($singleFile)) : 
					$uploadPath = 'images/products' . DIRECTORY_SEPARATOR . $singleFile;
					 echo '<a href="' . JRoute::_(JUri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
				endif;
			endforeach;
		?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_CATEGORY'); ?></th>
			<td><?php echo $this->item->category; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_LABEL'); ?></th>
			<td><?php echo $this->item->label; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_FEATURED'); ?></th>
			<td></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_PRICE'); ?></th>
			<td><?php echo $this->item->price; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_DOCUMENT'); ?></th>
			<td>
			<?php
			foreach ((array) $this->item->document as $singleFile) : 
				if (!is_array($singleFile)) : 
					$uploadPath = 'documents' . DIRECTORY_SEPARATOR . $singleFile;
					 echo '<a href="' . JRoute::_(JUri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
				endif;
			endforeach;
		?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_LINK'); ?></th>
			<td><?php echo $this->item->link; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_PRODUCT_CREATED_DATE'); ?></th>
			<td><?php echo $this->item->created_date; ?></td>
		</tr>

	</table>

</div>

