<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Dima_zarinpal
 * @author     Dima Group <info@dima.ir>
 * @copyright  Copyright (C) 2021 Dima Software Group. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;


?>

<div class="item_fields">

	<table class="table">
		

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_ORDER_PRODUCT'); ?></th>
			<td><?php echo $this->item->product; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_ORDER_PRICE'); ?></th>
			<td><?php echo $this->item->price; ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_ORDER_RFCODE'); ?></th>
			<td><?php echo nl2br($this->item->rfcode); ?></td>
		</tr>

		<tr>
			<th><?php echo JText::_('COM_DIMA_ZARINPAL_FORM_LBL_ORDER_CREATED_DATE'); ?></th>
			<td><?php echo $this->item->created_date; ?></td>
		</tr>

	</table>

</div>

