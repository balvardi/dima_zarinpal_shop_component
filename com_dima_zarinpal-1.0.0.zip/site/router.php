<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Dima_zarinpal
 * @author     Dima Group <info@dima.ir>
 * @copyright  Copyright (C) 2021 Dima Software Group. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Categories\Categories;

/**
 * Class Dima_zarinpalRouter
 *
 */
class Dima_zarinpalRouter extends RouterView
{
	private $noIDs;
	public function __construct($app = null, $menu = null)
	{
		$params = JComponentHelper::getComponent('com_dima_zarinpal')->params;
		$this->noIDs = (bool) $params->get('sef_ids');
		
		$products = new RouterViewConfiguration('products');
		$products->setKey('id')->setNestable();
		$this->registerView($products);
			$product = new RouterViewConfiguration('product');
			$product->setKey('id')->setParent($products, 'catid');
			$this->registerView($product);$orders = new RouterViewConfiguration('orders');
		$this->registerView($orders);
			$order = new RouterViewConfiguration('order');
			$order->setKey('id')->setParent($orders);
			$this->registerView($order);

		parent::__construct($app, $menu);

		$this->attachRule(new MenuRules($this));

		if ($params->get('sef_advanced', 0))
		{
			$this->attachRule(new StandardRules($this));
			$this->attachRule(new NomenuRules($this));
		}
		else
		{
			JLoader::register('Dima_zarinpalRulesLegacy', __DIR__ . '/helpers/legacyrouter.php');
			JLoader::register('Dima_zarinpalHelpersDima_zarinpal', __DIR__ . '/helpers/dima_zarinpal.php');
			$this->attachRule(new Dima_zarinpalRulesLegacy($this));
		}
	}


	
			/**
			 * Method to get the segment(s) for a category
			 *
			 * @param   string  $id     ID of the category to retrieve the segments for
			 * @param   array   $query  The request that is built right now
			 *
			 * @return  array|string  The segments of this item
			 */
			public function getProductsSegment($id, $query)
			{
				$category = Categories::getInstance('dima_zarinpal.products')->get($id);

				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';

					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}

					return $path;
				}

				return array();
			}
		/**
		 * Method to get the segment(s) for an product
		 *
		 * @param   string  $id     ID of the product to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getProductSegment($id, $query)
		{
			return array((int) $id => $id);
		}
		/**
		 * Method to get the segment(s) for an order
		 *
		 * @param   string  $id     ID of the order to retrieve the segments for
		 * @param   array   $query  The request that is built right now
		 *
		 * @return  array|string  The segments of this item
		 */
		public function getOrderSegment($id, $query)
		{
			return array((int) $id => $id);
		}

	
			/**
			 * Method to get the id for a category
			 *
			 * @param   string  $segment  Segment to retrieve the ID for
			 * @param   array   $query    The request that is parsed right now
			 *
			 * @return  mixed   The id of this item or false
			 */
			public function getProductsId($segment, $query)
			{
				if (isset($query['id']))
				{
					$category = Categories::getInstance('dima_zarinpal.products', array('access' => false))->get($query['id']);

					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}

				return false;
			}
		/**
		 * Method to get the segment(s) for an product
		 *
		 * @param   string  $segment  Segment of the product to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getProductId($segment, $query)
		{
			return (int) $segment;
		}
		/**
		 * Method to get the segment(s) for an order
		 *
		 * @param   string  $segment  Segment of the order to retrieve the ID for
		 * @param   array   $query    The request that is parsed right now
		 *
		 * @return  mixed   The id of this item or false
		 */
		public function getOrderId($segment, $query)
		{
			return (int) $segment;
		}
}
