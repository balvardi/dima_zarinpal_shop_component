<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Dima_zarinpal
 * @author     Dima Group <info@dima.ir>
 * @copyright  Copyright (C) 2021 Dima Software Group. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access.
defined('_JEXEC') or die;

/**
 * Send list controller class.
 *
 * @since  1.6
 */
class Dima_zarinpalControllerSend extends Dima_zarinpalController
{
	/**
	 * Proxy for getModel.
	 *
	 * @param   string  $name    The model name. Optional.
	 * @param   string  $prefix  The class prefix. Optional
	 * @param   array   $config  Configuration array for model. Optional
	 *
	 * @return object	The model
	 *
	 * @since	1.6
	 */
	public function &getModel($name = 'Send', $prefix = 'Dima_zarinpalModel', $config = array())
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));

		return $model;
	}
}
