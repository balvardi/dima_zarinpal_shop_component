<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Dima_zarinpal
 * @author     Dima Group <info@dima.ir>
 * @copyright  Copyright (C) 2021 Dima Software Group. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;

/**
 * Dima_zarinpal helper.
 *
 * @since  1.6
 */
class Dima_zarinpalHelper
{
	/**
	 * Configure the Linkbar.
	 *
	 * @param   string  $vName  string
	 *
	 * @return void
	 */
	public static function addSubmenu($vName = '')
	{
		JHtmlSidebar::addEntry(
			JText::_('COM_DIMA_ZARINPAL_TITLE_PRODUCTS'),
			'index.php?option=com_dima_zarinpal&view=products',
			$vName == 'products'
		);

		JHtmlSidebar::addEntry(
			JText::_('JCATEGORIES') . ' (' . JText::_('COM_DIMA_ZARINPAL_TITLE_PRODUCTS') . ')',
			"index.php?option=com_categories&extension=com_dima_zarinpal.products",
			$vName == 'categories.products'
		);
		if ($vName=='categories') {
			JToolBarHelper::title('Dima zarinpal Direct Shop: JCATEGORIES (COM_DIMA_ZARINPAL_TITLE_PRODUCTS)');
		}

JHtmlSidebar::addEntry(
			JText::_('COM_DIMA_ZARINPAL_TITLE_ORDERS'),
			'index.php?option=com_dima_zarinpal&view=orders',
			$vName == 'orders'
		);

		JHtmlSidebar::addEntry(
			JText::_('COM_DIMA_ZARINPAL_TITLE_DASHBOARD'),
			'index.php?option=com_dima_zarinpal&view=dashboard',
			$vName == 'dashboard'
		);
	}

	/**
	 * Gets the files attached to an item
	 *
	 * @param   int     $pk     The item's id
	 *
	 * @param   string  $table  The table's name
	 *
	 * @param   string  $field  The field's name
	 *
	 * @return  array  The files
	 */
	public static function getFiles($pk, $table, $field)
	{
		$db = Factory::getDbo();
		$query = $db->getQuery(true);

		$query
			->select($field)
			->from($table)
			->where('id = ' . (int) $pk);

		$db->setQuery($query);

		return explode(',', $db->loadResult());
	}

	/**
	 * Gets a list of the actions that can be performed.
	 *
	 * @return    JObject
	 *
	 * @since    1.6
	 */
	public static function getActions()
	{
		$user   = Factory::getUser();
		$result = new JObject;

		$assetName = 'com_dima_zarinpal';

		$actions = array(
			'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
		);

		foreach ($actions as $action)
		{
			$result->set($action, $user->authorise($action, $assetName));
		}

		return $result;
	}
}

