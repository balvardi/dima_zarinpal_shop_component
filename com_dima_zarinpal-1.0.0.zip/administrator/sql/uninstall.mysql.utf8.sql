DROP TABLE IF EXISTS `#__dima_zarinpal_products`;
DROP TABLE IF EXISTS `#__dima_zarinpal_orders`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_dima_zarinpal.%');